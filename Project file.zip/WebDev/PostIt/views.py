from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import PermissionDenied
from .forms import PostForm
from .models import Post

def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'signup.html', {'form': form})

@login_required
def CreateIt(request):
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.user = request.user
            post.save()
            return redirect('ViewIt')
    else:
        form = PostForm()
    return render(request, 'CreateIt.html', {'form': form})

@login_required
def EditIt(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    if post.user != request.user:
        raise PermissionDenied
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES, instance=post)
        if form.is_valid():
            form.save()
            return redirect('ViewIt')
    else:
        form = PostForm(instance=post)
    return render(request, 'EditIt.html', {'form': form})

@login_required
def DeletIt(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    if post.user != request.user:
        raise PermissionDenied
    if request.method == 'POST':
        post.delete()
        return redirect('ViewIt')
    return render(request, 'DeletIt.html', {'post': post})

def ViewIt(request):
    posts = Post.objects.all().order_by('-created_at')
    return render(request, 'ViewIt.html', {'posts': posts})

from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('', views.ViewIt, name='ViewIt'),
    path('post/new/', views.CreateIt, name='CreateIt'),
    path('post/edit/<int:post_id>/', views.EditIt, name='EditIt'),
    path('post/delete/<int:post_id>/', views.DeletIt, name='DeletIt'),
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('signup/', views.signup, name='signup'),
]
